package project11;

	class X {
		
			   public void methodX()
			   {
			     System.out.println("Class X method");
			   }
			}


